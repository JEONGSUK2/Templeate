import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { changeName } from '../store'

function Main() {


  return (
    <>
    <p></p> 
    </>
  )
}

export default Main